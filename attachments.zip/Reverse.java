
package excercise;

class Reverse1
{
void reverse1()
{         //using string buffer string builder
		String s1="logesh";
		StringBuffer buffer=new StringBuffer();
		buffer.append(s1);
		System.out.println(buffer.reverse());
}
//****************************************************************
    //own logic
void reverse2()
{
		String given="logesh";
		char[] charactorArray=given.toCharArray();
		String Reverse=" ";
		for(int i=charactorArray.length-1;i>=0;i--)
		{
		//for(int i=0;i<=charactorArray.length-1;i++) {
		Reverse=Reverse+charactorArray[i];
         }
	  System.out.println(Reverse);
}
//***********reverse the number using whikle loop***************

void reverse3()
{
     int number=12345;
     int reverse=0;
     while(number!=0)
     {
    	 int remainder=number % 10;
    	 reverse = number * 0 + remainder;
    	 number = number/10;
    	 
    	 System.out.print(reverse);
     }
}
//*************reverse the number using for loop**************

void reverse4()
{
	
	int reverse=0;
	for(int number=12345;number!=0;number=number/10)
	{
		int remainder=number % 10;
		reverse = number * 0 + remainder;
		
		System.out.print(reverse);
	}
}
//**********************string reverse charat method
void reverse5()
{
	String s1="abcd";
	for(int i=s1.length()-1;i>=0;i--)
	{
		System.out.print(s1.charAt(i));
	}
}
class Reverse
	{
	public static void main(String[] args)
	{
	   Reverse1 r1=new Reverse1();
	  // r1.reverse1();
	   //r1.reverse2();
	  // r1.reverse3();
	  // r1.reverse4();
	   r1.reverse5();
	}
	}
}
//----------------------------------------------------------------------------------