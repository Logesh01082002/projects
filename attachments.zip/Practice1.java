package excercise;
import java.util.*;

class Practice
{
void star()
	{
		int i=0;
		System.out.print("enter the number :");
		Scanner sc=new Scanner(System.in);
		int s=sc.nextInt();
		
		for(i=0;i<=s;i++)
		{
			for(int j=1;j<=i;j++)
			{
				System.out.print(" *");
			}
			System.out.println(" *");
		}
	}

void star2()
{
	int i=1;
	System.out.print("enter the number :");
	Scanner sc=new Scanner(System.in);
	int s=sc.nextInt();
	
	for(i=1;i<=s;i++)
	{
		for(int j=s;j>=i;j--)
		{
			System.out.print(" *");
		}
		System.out.println(" *");
	}
	
}
}
public class Practice1 
{
	public static void main(String ars[])
	{
		Practice p=new Practice();
		p.star2();
		
	}

}
